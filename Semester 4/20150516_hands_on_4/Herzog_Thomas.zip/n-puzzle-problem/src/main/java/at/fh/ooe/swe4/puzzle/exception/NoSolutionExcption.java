package at.fh.ooe.swe4.puzzle.exception;

public class NoSolutionExcption extends Exception {

	private static final long serialVersionUID = 5795850985936976146L;

	public NoSolutionExcption() {
		// TODO Auto-generated constructor stub
	}

	public NoSolutionExcption(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoSolutionExcption(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public NoSolutionExcption(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoSolutionExcption(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
