package at.fh.ooe.swe4.collections.api;

/**
 * Marker interface for an TreeNode
 * 
 * @author Thomas Herzog <thomas.herzog@students.fh-hagenberg.at>
 * @date May 17, 2015
 */
public interface Node<T> {
}
