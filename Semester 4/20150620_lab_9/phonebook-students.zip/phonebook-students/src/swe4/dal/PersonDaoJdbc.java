package swe4.dal;

import java.sql.*;
import java.util.*;

public class PersonDaoJdbc implements PersonDao {

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		
	}

 

} // PersonDaoJdbc