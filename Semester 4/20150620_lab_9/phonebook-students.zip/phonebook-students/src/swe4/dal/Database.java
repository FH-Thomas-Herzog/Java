package swe4.dal;

import java.sql.*;

public class Database {
 
} // DataBase