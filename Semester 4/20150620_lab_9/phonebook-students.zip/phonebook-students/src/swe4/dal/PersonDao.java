package swe4.dal;
import java.util.Collection;
import swe4.dal.DataAccessException;
import swe4.dal.Person;

// DAO interface for accessing Person table
public interface PersonDao extends AutoCloseable {
  
}