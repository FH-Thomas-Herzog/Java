package swe4.threading.producer_consumer;

public class Main {
  
  public static void main(String[] args) {
    // TODO
  }

}
