import java.util.Random;

public class Printer {
  private char          ch;
  private int           rows;
  private int           cols;

  public Printer(char ch, int rows, int cols) {
    this.ch = ch;
    this.rows = rows;
    this.cols = cols;
  }

  private void sleep(int millis) {
  }

  public void print1() {
  }

  public static void main(String[] args) {
    Printer p1 = new Printer('x', 10, 60);
    Printer p2 = new Printer('o', 10, 60);
  }
}