package swe4.threading;

public class Consumer extends Thread {
  public Consumer(String name, Buffer b) {
  } // Consumer

  public void run() {
  } // run
} // Consumer