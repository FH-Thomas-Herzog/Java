package swe4.threading;

public class Producer extends Thread {
  public Producer(String name, Buffer b) {
  } // Producer

  public void run() {
  } // run
} // Producer
